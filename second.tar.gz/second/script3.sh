#!/bin/bash

#For eggNOG mapper functional annotation, this website was used http://eggnogdb.embl.de/#/app/emapper
#the resulting file joinedlineoutput.fasta.emapper.annotations

#To count the total number of annotations
echo "This counts the total number of functional annotations"
echo ":::::::::::::::::::::::::::::::::::::::::::::::::::::"
egrep -o "GO:[0-9]{7}" joinedlineoutput.fasta.emapper.annotations | wc -l


#To count the number of transcripts that have annotations
echo "This counts the number of transcripts that have annotations"
egrep  "NODE" joinedlineoutput.fasta.emapper.annotations | wc -l

#############

#Questions about the new reference genome
#Counting the number of genes in the reference genome from gff
echo "This counts the number of genes in the reference genome from gff"
egrep -o "ID=gene[0-9]+" reference_genome.gff | wc -l

#Counting the summ of lenghts of all the annotated genes in gff file
echo "This counts the summ of lenghts of all the annotated genes in gff file"
awk 'NF > 0 { print ($5 - $4) }' reference_genome.gff | awk '{print (sum += $1)}'

#Create index for reference Genome with Bowtie2-build
echo "This creates index for reference Genome with Bowtie2-build"
bowtie2-build reference_genome.fna indexes

#Mapping
echo "Performing mappings (requires bowtie2!)"
bowtie2 -f -x indexes -U sample01.fastq -S aligned_sample_1 2>stats.txt
bowtie2 -f -x indexes -U sample02.fastq -S aligned_sample_2 2>stats2.txt
bowtie2 -f -x indexes -U sample03.fastq -S aligned_sample_3 2>stats3.txt
bowtie2 -f -x indexes -U sample04.fastq -S aligned_sample_4 2>stats4.txt

 
#Visualizing statistics of mappings
echo "This visualizes statistics of mappings"
cat stats.txt stats2.txt stats3.txt stats4.txt 

#To see the number of the reads in one of the samples
echo "This counts the number of the reads in one of the samples"
egrep -o "read" aligned_sample_1 | wc -l


# Convert to BAM and sort them
echo "This converts all SAM files in the folder to BAM files (requires samtools!)"
for i in 1 2 3 4
do
    samtools view -bS aligned_sample_$i > aligned_sample_try2_$i.bam
    samtools sort aligned_sample_try2_$i.bam sorted_sample_try2_$i
done

# Merge the already sorted bams and create the index
echo "What this does is it merges the already sorted bams and create the index"
samtools merge -r -h aligned_sample_1 merged_bam_try3 sorted_sample_try2_*
samtools index merged_bam_try3 merged_bai_try3

# Stats
echo "This returns the stats"
samtools flagstat merged_bam_try3

# Mpileup
echo "Mpileup is necessary to perform cariant calling"
samtools index 
samtools mpileup -g -f reference_genome.fna merged_bam_try3 > raw_mpileup_try3


# variant calling
echo "This performs variant calling"
echo ":::::::::::::::::::::::::::::"
bcftools view -bvcg raw_mpileup_try3 > snp_try3.bcf

# Results in .tsv with some columns and no header
echo "This transforms the output of the previous command into a .tsv table with only some columns and no header"
bcftools view snp_try3.bcf | grep -v "^#" | cut -f 1,2,4,5,6,8 | sed 's#DP=\([0-9][0-9]*\).*#\1#' > calls_try3.tsv

#Counting the number of entries
echo "Counting the number of entries"
cat calls_try3.tsv | wc -l

#Counting the number of INDELs (last column has an indication of whether the polymorphism is an INDEL)
echo "number of INDEL variants:"
cat calls_try3.tsv | grep "INDEL" | wc -l

#Counting the entries with a quality score >10 (qualities are on 5th column)
echo "entries with a quality score >10"
awk '$5>10' calls_try3.tsv | wc -l

#Same but for depth of coverage >10
echo "entries with a depth of coverage score >10"
awk '$5>10' calls_try3.tsv | wc -l

#Find the SNP with the best qualit
sort -k5 -n -r calls_try3.tsv | head -1
#Its an insertion ATT>ATTT at the position 2689416

#To find the gene, I used a filter to capture those genes that begin before and finish after the INDEL site
echo "To find the gene, I used a filter to capture those genes that begin before and finish after the INDEL site"
awk '$4<2689416 && $5>2689416' reference_genome.gff 
#Result:
#1148.67081.AP012205	RefSeq	gene	2689351	2690262	.	+	.	ID=gene2518;Name=SYNGTS_RS12550;gbkey=Gene;gene_biotype=protein_coding;locus_tag=SYNGTS_RS12550;old_locus_tag=SYNGTS_2418
#416 - 351 = 65

echo "The conclusion is ATT begins on the 3rd base of the codon, therefore in the protein TTN becomes TTT, it has a 50% of being neutral but the problem is the frameshift. Since it is at a begining of the protein (the 21st aminoacid, it has a great probability of being damaging)."

#Creating a bed file with minimal information to upload to IGV. A more correct
#approach would have been adding a 3rd column where it would be equal to the
#value of 2nd column + the lenght of the 3rd column of tsv file. But for simple
#visualization, its not needed.
echo "Creates a bed file that can be uploaded to IGV for visualization"
cat calls_try3.tsv | cut -f 1,2 > newfile.bed 



#HTSeq Count to display the number of reads mapping to each GFF feature
echo "HTSeq Count to display the number of reads mapping to each GFF feature"
for i in 1 2 3 4; do htseq-count -t gene -i old_locus_tag aligned_sample_$i reference_genome.gff; done

#Join the 4 files
join htseq_countfile_1 htseq_countfile_2 > htseq_count_12
join htseq_count_12 htseq_countfile_3 > htseq_count_123
join htseq_count_123 htseq_countfile_4 > htseq_count_all
