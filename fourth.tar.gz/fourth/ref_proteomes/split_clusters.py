# CPCantalapiedra 2018
#
import os
import sys

sys.stderr.write("split_clusters.py ...\n")
fafilen = sys.argv[1]
outdir = os.path.realpath(sys.argv[2])

prev_is_header = True # first line of file should be a cluster
previd = None
currcl = None
currpr = None
with open(fafilen) as fafile:
	
	for faline in fafile:
		
		if faline.startswith(">"):
			currid = faline[1:].split()[0]
			
			if prev_is_header:
				if previd:
					currcl = previd
				else:
					currcl = currid # first line of file
				sys.stderr.write("Cluster "+str(currcl)+"\n")
			#else:
			#	print "Protein "+str(currid)
		else:
			currpr = previd
			currseq = faline.strip()
			currfilen = os.path.join(outdir, currcl+".fa")
			sys.stderr.write("Writing "+currpr+" to "+currfilen+"\n")
			sys.stderr.write(currseq+"\n")
			with open(currfilen, 'a') as currfile:
				currfile.write(">"+currpr+"\n"+currseq+"\n")
			
		
		previd = currid
		prev_is_header = faline.startswith(">")

sys.stderr.write("Finished.\n")

# END
