#!/bin/bash

####ORTHOLOGY####

#1st, I concatenated the proteome FASTA file of the target organism with the
#proteomes of the organisms I want to compare (all in one file)
cat ref_proteomes/*faa > concatenated_proteomes.faa
cat reference_proteome.faa >> concatenated_proteomes.faa

#Using mmseqs2 to create clusters of proteins (belonging to the same family)
# Create a database with all sequences 
./mmseqs createdb concatenated_proteomes.faa concatenated_proteomes.db
# identify clusters by sequence similarity (with min coverage set to 10%)
./mmseqs cluster concatenated_proteomes.db  concatenated_proteomes.clusters tmp/ -c 0.1

#Converting each cluster of proteins into a separate FASTA file. For that, I use the
#split_clusters.py script. But to use it, first I need to:
#1)Create a database of clusters with mmseqscreate seq file db
./mmseqs createseqfiledb concatenated_proteomes.db concatenated_proteomes.clusters clusters.seq
#2)convert them into fasta format with mmseqs result2flat
./mmseqs result2flat concatenated_proteomes.db concatenated_proteomes.db clusters.seq clusters.fasta

#Finally splitting clusters
mkdir splitted_clusters
python split_clusters.py clusters.fasta splitted_clusters/

#From all the clusters created (a lot), identify only those that contain the genes found differentially
#expressed in light VS in dark (see DES.R script for how they are identified). These genes are:
#SYNGTS_0480
#SYNGTS_1416
#SYNGTS_2578
#SYNGTS_2822

grep -E "SYNGTS_0480|SYNGTS_1416|SYNGTS_2578|SYNGTS_2822" splitted_clusters/*

#Output:
#splitted_clusters/Arabidopsis_thaliana.AT2G27070.1.fa:>Synechocystis_sp.SYNGTS_2822
#splitted_clusters/Arabidopsis_thaliana.AT2G27070.1.fa:>Synechocystis_sp.SYNGTS_2578
#splitted_clusters/Cyanothece_sp.Cyan7425_3552.fa:>Synechocystis_sp.SYNGTS_0480
#splitted_clusters/Cyanothece_sp.Cyan7425_3552.fa:>Synechocystis_sp.SYNGTS_1416

#Building a philogenetic tree for these 4 clusters.
#This is done with ete3 and using python2, therefore after installation of ete3, python version must be downgraded to 2
echo "#Building a philogenetic tree for these 4 clusters.
#This is done with ete3 and using python2, therefore after installation of ete3, python version must be downgraded to 2"

#now it can be done
mkdir fasta_trees

ete3 build -w standard_fasttree -a splitted_clusters/Arabidopsis_thaliana.AT2G27070.1.fa -o fasta_trees/fasta1.tree --clearall --compress -t 0.5 --launch-time 1 --noimg
ete3 build -w standard_fasttree -a splitted_clusters/Cyanothece_sp.Cyan7425_3552.fa -o fasta2.tree --clearall --compress -t 0.5 --launch-time 1 --noimg


